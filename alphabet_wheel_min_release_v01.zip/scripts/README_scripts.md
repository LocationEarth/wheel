# Scripts — minimal snippets

**Wheel energy E (continuous angles)**
```python
import numpy as np, pandas as pd
C = pd.read_csv('data/bigram_counts_de.csv').rename(columns={'from':'src','to':'dst','n':'count'})
A = pd.read_csv('data/operator_wheel_coords_de.csv')
if 'angle_rad' not in A: A['angle_rad'] = np.deg2rad(A['angle_deg'].astype(float))
tokens = A['token'].str.upper().tolist(); idx = {t:i for i,t in enumerate(tokens)}
M = np.zeros((len(tokens),len(tokens)))
for r in C.itertuples(index=False):
    s,d = r.src.upper(), r.dst.upper()
    if s in idx and d in idx: M[idx[s], idx[d]] += r.count
theta = A.set_index('token').loc[tokens, 'angle_rad'].values
d = np.arccos(np.cos(theta[:,None]-theta[None,:])); E = float((M/M.sum()*d).sum())
print('E=', E)
```

**Mod‑N sector centers**
```python
def sector_centers(theta, N):
    bins = np.floor((theta%(2*np.pi))/(2*np.pi/N)).astype(int)
    return (bins+0.5)*(2*np.pi/N)
```

**PMI + Δθ for chords**
```python
total = M.sum(); p = M/total; pi = p.sum(1, keepdims=True); pj = p.sum(0, keepdims=True)
PMI = np.log(p/(pi@pj)); PMI[~np.isfinite(PMI)] = 0
```
